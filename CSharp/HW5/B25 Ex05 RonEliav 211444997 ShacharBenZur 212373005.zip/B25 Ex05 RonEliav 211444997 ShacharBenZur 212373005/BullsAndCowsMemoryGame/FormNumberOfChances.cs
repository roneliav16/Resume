﻿using System;
using System.Windows.Forms;

namespace BullsAndCowsMemoryGame
{
    public partial class FormNumberOfChances : Form
    {
        private const int k_MinChances = 4;
        private const int k_MaxChances = 10;
        private int m_NumberOfChances = k_MinChances;
        private bool m_ButtonStartClicked = false;

        public bool ButtonStartClicked
        {
            get
            {
                return m_ButtonStartClicked;
            }
        }

        public int NumberOfChances
        {
            get
            {
                return m_NumberOfChances;
            }
            set
            {
                if (value >= k_MinChances && value <= k_MaxChances)
                {
                    m_NumberOfChances = value;
                }
                else
                {
                    m_NumberOfChances = k_MinChances; // Reset to default if out of range (allows cyclic choice)
                }

                m_ButtonNumberOfChances.Text = "Number of chances: " + NumberOfChances;
            }
        }

        public FormNumberOfChances()
        {
            InitializeComponent();
        }

        private void m_ButtonNumberOfChances_Click(object sender, EventArgs e)
        {
            NumberOfChances++; // Increment the number of chances
            m_ButtonNumberOfChances.Text = "Number of chances: " + NumberOfChances;
        }

        private void m_ButtonStart_Click(object sender, EventArgs e)
        {
            m_ButtonStartClicked = true;
            this.Close();
        }
    }
}
